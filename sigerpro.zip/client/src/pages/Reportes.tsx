import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Plus, Trash2, AlertTriangle, Clock, CheckCircle2, PlusCircle } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

/**
 * Reportes Page - Monthly PDF Report Generation and Download
 */

interface Reporte {
  id: number;
  titulo: string;
  mes: number;
  anio: number;
  nombreArchivo: string;
  fechaGeneracion: Date;
  descargas: number;
  estadisticas: {
    total: number;
    bajo: number;
    medio: number;
    alto: number;
    critico: number;
  };
}

const MESES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];

export default function Reportes() {
  const [reportes, setReportes] = useState<Reporte[]>([
    {
      id: 1,
      titulo: "Reporte de Riesgos - FEBRERO 2026",
      mes: 2,
      anio: 2026,
      nombreArchivo: "reporte_febrero_2026.pdf",
      fechaGeneracion: new Date("2026-02-28"),
      descargas: 3,
      estadisticas: {
        total: 174,
        bajo: 17,
        medio: 10,
        alto: 53,
        critico: 94,
      },
    },
  ]);

  const [generando, setGenerando] = useState(false);
  const [mesSeleccionado, setMesSeleccionado] = useState(2);
  const [anioSeleccionado, setAnioSeleccionado] = useState(2026);

  const handleGenerarReporte = async () => {
    setGenerando(true);
    try {
      // Simular generación de reporte
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const nuevoReporte: Reporte = {
        id: reportes.length + 1,
        titulo: `Reporte de Riesgos - ${MESES[mesSeleccionado - 1].toUpperCase()} ${anioSeleccionado}`,
        mes: mesSeleccionado,
        anio: anioSeleccionado,
        nombreArchivo: `reporte_${MESES[mesSeleccionado - 1].toLowerCase()}_${anioSeleccionado}.pdf`,
        fechaGeneracion: new Date(),
        descargas: 0,
        estadisticas: {
          total: 174,
          bajo: 17,
          medio: 10,
          alto: 53,
          critico: 94,
        },
      };

      setReportes([nuevoReporte, ...reportes]);
      toast.success("Reporte generado exitosamente");
    } catch (error) {
      toast.error("Error al generar el reporte");
    } finally {
      setGenerando(false);
    }
  };

  const handleDescargar = (reporte: Reporte) => {
    toast.success(`Descargando ${reporte.nombreArchivo}`);
    // En producción, aquí se descargaría el archivo real
  };

  const handleEliminar = (id: number) => {
    setReportes(reportes.filter((r) => r.id !== id));
    toast.success("Reporte eliminado");
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Reportes</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Genera y descarga reportes mensuales de análisis de riesgos en
              formato PDF
            </p>
          </div>
        </div>

        {/* Generador de Reportes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              Generar Nuevo Reporte
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground">
                  Mes
                </label>
                <select
                  value={mesSeleccionado}
                  onChange={(e) => setMesSeleccionado(Number(e.target.value))}
                  className="w-full mt-2 px-3 py-2 border border-input rounded-md bg-background text-foreground"
                >
                  {MESES.map((mes, idx) => (
                    <option key={mes} value={idx + 1}>
                      {mes}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">
                  Año
                </label>
                <select
                  value={anioSeleccionado}
                  onChange={(e) => setAnioSeleccionado(Number(e.target.value))}
                  className="w-full mt-2 px-3 py-2 border border-input rounded-md bg-background text-foreground"
                >
                  {[2024, 2025, 2026, 2027].map((anio) => (
                    <option key={anio} value={anio}>
                      {anio}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-end">
                <Button
                  onClick={handleGenerarReporte}
                  disabled={generando}
                  className="w-full"
                >
                  {generando ? "Generando..." : "Generar Reporte"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Reportes */}
        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">
            Reportes Disponibles
          </h2>

          {reportes.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">
                    No hay reportes disponibles
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {reportes.map((reporte) => (
                <Card key={reporte.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground">
                          {reporte.titulo}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          Generado:{" "}
                          {reporte.fechaGeneracion.toLocaleDateString("es-ES")}
                        </p>

                        {/* Estadísticas */}
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4">
                          <div className="p-2 bg-muted rounded">
                            <p className="text-xs text-muted-foreground">
                              Total
                            </p>
                            <p className="text-lg font-bold text-foreground">
                              {reporte.estadisticas.total}
                            </p>
                          </div>
                          <div className="p-2 bg-green-50 dark:bg-green-950 rounded">
                            <p className="text-xs text-muted-foreground">
                              Bajo
                            </p>
                            <p className="text-lg font-bold text-green-600 dark:text-green-400">
                              {reporte.estadisticas.bajo}
                            </p>
                          </div>
                          <div className="p-2 bg-yellow-50 dark:bg-yellow-950 rounded">
                            <p className="text-xs text-muted-foreground">
                              Medio
                            </p>
                            <p className="text-lg font-bold text-yellow-600 dark:text-yellow-400">
                              {reporte.estadisticas.medio}
                            </p>
                          </div>
                          <div className="p-2 bg-orange-50 dark:bg-orange-950 rounded">
                            <p className="text-xs text-muted-foreground">
                              Alto
                            </p>
                            <p className="text-lg font-bold text-orange-600 dark:text-orange-400">
                              {reporte.estadisticas.alto}
                            </p>
                          </div>
                          <div className="p-2 bg-red-50 dark:bg-red-950 rounded">
                            <p className="text-xs text-muted-foreground">
                              Crítico
                            </p>
                            <p className="text-lg font-bold text-red-600 dark:text-red-400">
                              {reporte.estadisticas.critico}
                            </p>
                          </div>
                        </div>

                        <p className="text-xs text-muted-foreground mt-3">
                          Descargas: {reporte.descargas}
                        </p>
                      </div>

                      {/* Acciones */}
                      <div className="flex gap-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDescargar(reporte)}
                          className="gap-1"
                        >
                          <Download className="w-4 h-4" />
                          Descargar
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleEliminar(reporte.id)}
                          className="gap-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Información */}
        <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
              ℹ️ Acerca de los Reportes
            </h3>
            <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <li>
                • Los reportes se generan automáticamente cada fin de mes
              </li>
              <li>
                • Incluyen análisis completo de evaluaciones de riesgos
              </li>
              <li>
                • Contienen gráficos de distribución por tipo y regulación
              </li>
              <li>
                • Se pueden descargar en cualquier momento en formato PDF
              </li>
              <li>
                • Cumplen con estándares OACI de seguridad operacional
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
