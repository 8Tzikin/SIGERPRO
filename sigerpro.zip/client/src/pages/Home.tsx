import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { AlertCircle, BarChart3, CheckCircle, ClipboardList, Shield } from "lucide-react";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to dashboard after authentication
  useEffect(() => {
    if (isAuthenticated && user && !loading) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, user, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white">Cargando...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticated && user) {
    // Redirect is handled by useEffect, return loading state
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="bg-slate-900/80 backdrop-blur border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Shield className="w-8 h-8 text-blue-400" />
            <span className="text-xl font-bold text-white">SIGER PRO</span>
          </div>
          <a href={getLoginUrl()} className="text-white hover:text-blue-400 transition">
            <Button variant="outline" className="border-blue-400 text-blue-400 hover:bg-blue-400/10">
              Ingresar
            </Button>
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Gestión de Riesgos Operacionales
          </h1>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Sistema integral para la evaluación, seguimiento y análisis de riesgos de seguridad operacional aeronáutica según estándares OACI.
          </p>
          <div className="flex gap-3 justify-center">
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-blue-500 hover:bg-blue-600 text-white">
                Acceder a SIGER PRO
              </Button>
            </a>
            <Button size="lg" variant="outline" onClick={() => setLocation("/demo")} className="border-blue-400 text-blue-400 hover:bg-blue-400/10">
              Acceso Demo
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <AlertCircle className="w-8 h-8 text-amber-400 mb-2" />
              <CardTitle className="text-white">Evaluaciones de Riesgos</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-400">
              Captura y gestión de reportes de incidentes y peligros operacionales.
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <BarChart3 className="w-8 h-8 text-green-400 mb-2" />
              <CardTitle className="text-white">Análisis y Indicadores</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-400">
              Dashboard con gráficos y métricas de tendencias de riesgos.
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <ClipboardList className="w-8 h-8 text-blue-400 mb-2" />
              <CardTitle className="text-white">Seguimiento</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-400">
              Registro de acciones, comentarios y auditoría de cambios.
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition">
            <CardHeader>
              <CheckCircle className="w-8 h-8 text-emerald-400 mb-2" />
              <CardTitle className="text-white">Control de Acceso</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-400">
              Gestión de roles y permisos para SUPER_ADMIN, ADMINISTRADOR y AUDITOR.
            </CardContent>
          </Card>
        </div>

        {/* Key Features */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 mb-20">
          <h2 className="text-2xl font-bold text-white mb-6">Funcionalidades Principales</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-blue-400 mb-3">Gestión de Evaluaciones</h3>
              <ul className="space-y-2 text-slate-300">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  Cálculo automático de índice de riesgo inherente y resultante
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  Clasificación de riesgos (Bajo, Medio, Alto, Crítico)
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  Seguimiento de acciones y recomendaciones
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  Gestión de normativa aplicable (RAC, AIES-SOARG, NSOAM)
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-blue-400 mb-3">Análisis y Reportes</h3>
              <ul className="space-y-2 text-slate-300">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  Dashboard con indicadores KPI en tiempo real
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  Gráficos de distribución y tendencias de riesgos
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  Exportación de datos a Excel
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                  Bitácora de auditoría completa
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Standards */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8">
          <h2 className="text-2xl font-bold text-white mb-4">Cumplimiento de Estándares</h2>
          <p className="text-slate-300 mb-4">
            SIGER PRO implementa los estándares internacionales de la Organización de Aviación Civil Internacional (OACI) para la gestión de riesgos operacionales:
          </p>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-slate-700/50 p-4 rounded">
              <p className="font-semibold text-blue-400">Escala de Probabilidad OACI</p>
              <p className="text-sm text-slate-400 mt-2">Remoto, Ocasional, Frecuente</p>
            </div>
            <div className="bg-slate-700/50 p-4 rounded">
              <p className="font-semibold text-blue-400">Escala de Severidad OACI</p>
              <p className="text-sm text-slate-400 mt-2">A-E (Muy Baja a Crítica)</p>
            </div>
            <div className="bg-slate-700/50 p-4 rounded">
              <p className="font-semibold text-blue-400">Matriz de Riesgo</p>
              <p className="text-sm text-slate-400 mt-2">Cálculo automático de índices</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-700 mt-20 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-slate-400">
          <p>© 2025 SIGER PRO - Sistema de Gestión de Riesgos Operacionales Aeronáuticos</p>
        </div>
      </footer>
    </div>
  );
}
