import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { useState, useMemo } from "react";
import { ArrowLeft } from "lucide-react";

export default function NuevaInspección() {
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    categoryId: "",
    description: "",
    findings: "",
    correctiveActions: "",
    inspectionDate: new Date().toISOString().split("T")[0],
    inspector: "",
    location: "",
    priority: "media",
    notes: "",
  });

  const { data: categories } = trpc.inspections.categories.list.useQuery();
  const createMutation = trpc.inspections.create.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const inspectionDate = new Date(formData.inspectionDate).getTime();
      
      await createMutation.mutateAsync({
        categoryId: parseInt(formData.categoryId),
        description: formData.description,
        findings: formData.findings,
        correctiveActions: formData.correctiveActions,
        inspectionDate,
        inspector: formData.inspector,
        location: formData.location,
        priority: formData.priority as "baja" | "media" | "alta" | "critica",
        notes: formData.notes,
      });

      toast.success("Inspección creada exitosamente");
      setLocation("/inspecciones");
    } catch (error) {
      toast.error("Error al crear la inspección");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation("/inspecciones")}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Nueva Inspección</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Registra una nueva inspección de aeródromo
          </p>
        </div>
      </div>

      {/* Form */}
      <Card>
        <CardHeader>
          <CardTitle>Información de la Inspección</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Category */}
            <div>
              <label className="text-sm font-medium">Categoría de Inspección *</label>
              <Select
                value={formData.categoryId}
                onValueChange={(value) => handleChange("categoryId", value)}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Selecciona una categoría" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id.toString()}>
                      {cat.code} - {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Inspection Date */}
            <div>
              <label className="text-sm font-medium">Fecha de Inspección *</label>
              <Input
                type="date"
                value={formData.inspectionDate}
                onChange={(e) => handleChange("inspectionDate", e.target.value)}
                className="mt-1"
              />
            </div>

            {/* Inspector */}
            <div>
              <label className="text-sm font-medium">Inspector</label>
              <Input
                type="text"
                placeholder="Nombre del inspector"
                value={formData.inspector}
                onChange={(e) => handleChange("inspector", e.target.value)}
                className="mt-1"
              />
            </div>

            {/* Location */}
            <div>
              <label className="text-sm font-medium">Ubicación</label>
              <Input
                type="text"
                placeholder="Ubicación de la inspección"
                value={formData.location}
                onChange={(e) => handleChange("location", e.target.value)}
                className="mt-1"
              />
            </div>

            {/* Priority */}
            <div>
              <label className="text-sm font-medium">Prioridad</label>
              <Select
                value={formData.priority}
                onValueChange={(value) => handleChange("priority", value)}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="baja">Baja</SelectItem>
                  <SelectItem value="media">Media</SelectItem>
                  <SelectItem value="alta">Alta</SelectItem>
                  <SelectItem value="critica">Crítica</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Description */}
            <div>
              <label className="text-sm font-medium">Descripción</label>
              <Textarea
                placeholder="Descripción de la inspección"
                value={formData.description}
                onChange={(e) => handleChange("description", e.target.value)}
                className="mt-1 min-h-24"
              />
            </div>

            {/* Findings */}
            <div>
              <label className="text-sm font-medium">Hallazgos</label>
              <Textarea
                placeholder="Hallazgos encontrados durante la inspección"
                value={formData.findings}
                onChange={(e) => handleChange("findings", e.target.value)}
                className="mt-1 min-h-24"
              />
            </div>

            {/* Corrective Actions */}
            <div>
              <label className="text-sm font-medium">Acciones Correctivas</label>
              <Textarea
                placeholder="Acciones correctivas recomendadas"
                value={formData.correctiveActions}
                onChange={(e) => handleChange("correctiveActions", e.target.value)}
                className="mt-1 min-h-24"
              />
            </div>

            {/* Notes */}
            <div>
              <label className="text-sm font-medium">Notas Adicionales</label>
              <Textarea
                placeholder="Notas adicionales"
                value={formData.notes}
                onChange={(e) => handleChange("notes", e.target.value)}
                className="mt-1 min-h-20"
              />
            </div>

            {/* Buttons */}
            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation("/inspecciones")}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={isSubmitting || !formData.categoryId}>
                {isSubmitting ? "Guardando..." : "Guardar Inspección"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
