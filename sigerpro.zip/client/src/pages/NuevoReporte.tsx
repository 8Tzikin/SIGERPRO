import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { useState } from "react";
import { ArrowLeft } from "lucide-react";

const TIPOS_OCURRENCIA = [
  "Falla de Pavimento",
  "Falla de Vallas y Caminos",
  "Falla de Luces",
  "Falla de Drenajes",
  "Falla de Letreros",
  "Falla de Franjas",
  "Falla de Radio Ayudas",
  "Inspección Nocturna",
  "Falla de Señalización",
  "Falla de Construcciones",
  "Falla de Combustibles",
  "Fuente Secundaria",
  "Materiales Peligrosos",
  "Inspección Especial",
  "Obstáculos",
  "SEI",
  "SOAM",
  "Fauna",
  "FOD",
];

const FORMAS_REPORTE = [
  "OUTLOOK/REPORTES AGA",
  "WHATSAPP",
  "CORREO ELECTRÓNICO",
  "LLAMADA TELEFÓNICA",
  "PRESENCIAL",
  "OTRO",
];

export default function NuevoReporte() {
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    numero: 0,
    fecha: new Date().toISOString().split("T")[0],
    formaReporte: "",
    reportadoPor: "",
    entidadOrigen: "",
    descripcion: "",
    tipoOcurrencia: "",
    regulacionAplicable: "",
    normativaAIES: "",
    causaRaiz: "",
    probabilidad: 1,
    severidad: 1,
    accionesAplicadas: "",
    responsabilidad: "",
    seInvestiga: false,
    estado: "ABIERTO",
  });

  const createMutation = trpc.riskReports.create.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await createMutation.mutateAsync({
        numero: formData.numero || Math.floor(Math.random() * 10000),
        fecha: formData.fecha,
        reportadoPor: formData.reportadoPor,
        descripcion: formData.descripcion,
        tipoOcurrencia: formData.tipoOcurrencia,
        probabilidad: formData.probabilidad,
        severidad: formData.severidad,
        estado: formData.estado as "ABIERTO" | "SEGUIMIENTO" | "CERRADO",
      });

      toast.success("Reporte creado exitosamente");
      setLocation("/reportes");
    } catch (error) {
      toast.error("Error al crear el reporte");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const indiceRiesgo = formData.probabilidad * formData.severidad;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation("/reportes")}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Nuevo Reporte de Riesgo</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Registra un nuevo reporte de riesgo operacional
          </p>
        </div>
      </div>

      {/* Form */}
      <Card>
        <CardHeader>
          <CardTitle>Información del Reporte</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              {/* Fecha */}
              <div>
                <label className="text-sm font-medium">Fecha del Reporte *</label>
                <Input
                  type="date"
                  value={formData.fecha}
                  onChange={(e) => handleChange("fecha", e.target.value)}
                  className="mt-1"
                />
              </div>

              {/* Forma de Reporte */}
              <div>
                <label className="text-sm font-medium">Forma de Reporte</label>
                <Select
                  value={formData.formaReporte}
                  onValueChange={(value) => handleChange("formaReporte", value)}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Selecciona forma" />
                  </SelectTrigger>
                  <SelectContent>
                    {FORMAS_REPORTE.map((forma) => (
                      <SelectItem key={forma} value={forma}>
                        {forma}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Reportado Por */}
            <div>
              <label className="text-sm font-medium">Reportado Por *</label>
              <Input
                type="text"
                placeholder="Nombre de la persona"
                value={formData.reportadoPor}
                onChange={(e) => handleChange("reportadoPor", e.target.value)}
                className="mt-1"
              />
            </div>

            {/* Entidad de Origen */}
            <div>
              <label className="text-sm font-medium">Entidad de Origen</label>
              <Input
                type="text"
                placeholder="Entidad de origen"
                value={formData.entidadOrigen}
                onChange={(e) => handleChange("entidadOrigen", e.target.value)}
                className="mt-1"
              />
            </div>

            {/* Tipo de Ocurrencia */}
            <div>
              <label className="text-sm font-medium">Tipo de Ocurrencia *</label>
              <Select
                value={formData.tipoOcurrencia}
                onValueChange={(value) => handleChange("tipoOcurrencia", value)}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Selecciona tipo" />
                </SelectTrigger>
                <SelectContent>
                  {TIPOS_OCURRENCIA.map((tipo) => (
                    <SelectItem key={tipo} value={tipo}>
                      {tipo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Descripción */}
            <div>
              <label className="text-sm font-medium">Descripción del Reporte *</label>
              <Textarea
                placeholder="Describe el reporte detalladamente"
                value={formData.descripcion}
                onChange={(e) => handleChange("descripcion", e.target.value)}
                className="mt-1 min-h-24"
              />
            </div>

            {/* Regulación Aplicable */}
            <div>
              <label className="text-sm font-medium">Regulación Aplicable</label>
              <Input
                type="text"
                placeholder="Regulación aplicable"
                value={formData.regulacionAplicable}
                onChange={(e) => handleChange("regulacionAplicable", e.target.value)}
                className="mt-1"
              />
            </div>

            {/* Causa Raíz */}
            <div>
              <label className="text-sm font-medium">Causa Raíz</label>
              <Textarea
                placeholder="Análisis de causa raíz"
                value={formData.causaRaiz}
                onChange={(e) => handleChange("causaRaiz", e.target.value)}
                className="mt-1 min-h-20"
              />
            </div>

            {/* Probabilidad y Severidad */}
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium">Probabilidad (1-5)</label>
                <Input
                  type="number"
                  min="1"
                  max="5"
                  value={formData.probabilidad}
                  onChange={(e) => handleChange("probabilidad", parseInt(e.target.value))}
                  className="mt-1"
                />
              </div>

              <div>
                <label className="text-sm font-medium">Severidad (1-5)</label>
                <Input
                  type="number"
                  min="1"
                  max="5"
                  value={formData.severidad}
                  onChange={(e) => handleChange("severidad", parseInt(e.target.value))}
                  className="mt-1"
                />
              </div>

              <div>
                <label className="text-sm font-medium">Índice de Riesgo</label>
                <div className="mt-1 p-2 bg-muted rounded text-center font-bold">
                  {indiceRiesgo}
                </div>
              </div>
            </div>

            {/* Acciones Aplicadas */}
            <div>
              <label className="text-sm font-medium">Acciones Aplicadas</label>
              <Textarea
                placeholder="Acciones aplicadas en el momento"
                value={formData.accionesAplicadas}
                onChange={(e) => handleChange("accionesAplicadas", e.target.value)}
                className="mt-1 min-h-20"
              />
            </div>

            {/* Responsabilidad */}
            <div>
              <label className="text-sm font-medium">Responsabilidad</label>
              <Input
                type="text"
                placeholder="Responsable"
                value={formData.responsabilidad}
                onChange={(e) => handleChange("responsabilidad", e.target.value)}
                className="mt-1"
              />
            </div>

            {/* Se Investiga */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="seInvestiga"
                checked={formData.seInvestiga}
                onChange={(e) => handleChange("seInvestiga", e.target.checked)}
                className="w-4 h-4"
              />
              <label htmlFor="seInvestiga" className="text-sm font-medium cursor-pointer">
                ¿Se investiga?
              </label>
            </div>

            {/* Estado */}
            <div>
              <label className="text-sm font-medium">Estado</label>
              <Select
                value={formData.estado}
                onValueChange={(value) => handleChange("estado", value)}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ABIERTO">Abierto</SelectItem>
                  <SelectItem value="SEGUIMIENTO">Seguimiento</SelectItem>
                  <SelectItem value="CERRADO">Cerrado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Buttons */}
            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation("/reportes")}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting || !formData.reportadoPor || !formData.descripcion}
              >
                {isSubmitting ? "Guardando..." : "Guardar Reporte"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
