import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ClipboardCheck,
  AlertTriangle,
  Clock,
  CheckCircle2,
  PlusCircle,
  ArrowRight,
  Plane,
} from "lucide-react";
import { useLocation } from "wouter";
import { useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const STATUS_LABELS = {
  abierta: "Abierta",
  en_seguimiento: "En Seguimiento",
  cerrada: "Cerrada",
};

const STATUS_COLORS = {
  abierta: "#ef4444",
  en_seguimiento: "#f59e0b",
  cerrada: "#10b981",
};

const PRIORITY_COLORS = {
  baja: "#10b981",
  media: "#3b82f6",
  alta: "#f59e0b",
  critica: "#ef4444",
};

export default function InspeccionesAerodromo() {
  const [, setLocation] = useLocation();

  const now = useMemo(() => Date.now(), []);
  const startOfYear = useMemo(() => new Date(2026, 0, 1).getTime(), []);
  const endOfYear = useMemo(() => new Date(2026, 11, 31, 23, 59, 59).getTime(), []);

  const { data: categories } = trpc.inspections.categories.list.useQuery();
  const { data: inspectionsData, isLoading: loadingInspections } = trpc.inspections.list.useQuery({
    limit: 200,
    offset: 0,
  });
  const { data: statsData } = trpc.inspections.stats.useQuery({
    dateFrom: startOfYear,
    dateTo: endOfYear,
  });

  const stats = useMemo(() => {
    if (!inspectionsData) return { total: 0, abiertas: 0, enSeguimiento: 0, cerradas: 0 };
    const items = inspectionsData.items;
    return {
      total: inspectionsData.total,
      abiertas: items.filter((i) => i.status === "abierta").length,
      enSeguimiento: items.filter((i) => i.status === "en_seguimiento").length,
      cerradas: items.filter((i) => i.status === "cerrada").length,
    };
  }, [inspectionsData]);

  const pieData = useMemo(() => {
    return [
      { name: "Abiertas", value: stats.abiertas, color: STATUS_COLORS.abierta },
      { name: "En Seguimiento", value: stats.enSeguimiento, color: STATUS_COLORS.en_seguimiento },
      { name: "Cerradas", value: stats.cerradas, color: STATUS_COLORS.cerrada },
    ].filter((d) => d.value > 0);
  }, [stats]);

  const barData = useMemo(() => {
    if (!inspectionsData || !categories) return [];
    const catMap = new Map(categories.map((c) => [c.id, c.code]));
    const grouped: Record<string, number> = {};
    for (const inspection of inspectionsData.items) {
      const code = catMap.get(inspection.categoryId) || "?";
      grouped[code] = (grouped[code] || 0) + 1;
    }
    return Object.entries(grouped)
      .map(([code, count]) => ({ code, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [inspectionsData, categories]);

  const recentInspections = useMemo(() => {
    if (!inspectionsData || !categories) return [];
    const catMap = new Map(categories.map((c) => [c.id, c]));
    return inspectionsData.items.slice(0, 5).map((i) => ({
      ...i,
      category: catMap.get(i.categoryId),
    }));
  }, [inspectionsData, categories]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Plane className="w-6 h-6" />
            Dashboard de Inspecciones de Aeródromo
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Gestión integral de inspecciones del programa 2026
          </p>
        </div>
        <Button onClick={() => setLocation("/inspecciones/nueva")} className="gap-2">
          <PlusCircle className="w-4 h-4" />
          Nueva Inspección
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Inspecciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingInspections ? (
              <Skeleton className="h-8 w-12" />
            ) : (
              <div className="text-2xl font-bold">{stats.total}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              Todas las inspecciones registradas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500" />
              Abiertas
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingInspections ? (
              <Skeleton className="h-8 w-12" />
            ) : (
              <div className="text-2xl font-bold text-red-600">{stats.abiertas}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              Requieren atención inmediata
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-500" />
              En Seguimiento
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingInspections ? (
              <Skeleton className="h-8 w-12" />
            ) : (
              <div className="text-2xl font-bold text-amber-600">{stats.enSeguimiento}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              En proceso de resolución
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              Cerradas
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingInspections ? (
              <Skeleton className="h-8 w-12" />
            ) : (
              <div className="text-2xl font-bold text-green-600">{stats.cerradas}</div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              Completadas y cerradas
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Estado de Inspecciones</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingInspections ? (
              <Skeleton className="h-64 w-full" />
            ) : pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                Sin datos disponibles
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Inspecciones por Categoría</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingInspections ? (
              <Skeleton className="h-64 w-full" />
            ) : barData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={barData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="code" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                Sin datos disponibles
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Inspections */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Inspecciones Recientes</CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/inspecciones")}
            className="gap-1"
          >
            Ver todas
            <ArrowRight className="w-4 h-4" />
          </Button>
        </CardHeader>
        <CardContent>
          {loadingInspections ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : recentInspections.length > 0 ? (
            <div className="space-y-2">
              {recentInspections.map((inspection) => (
                <div
                  key={inspection.id}
                  className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent cursor-pointer transition-colors"
                  onClick={() => setLocation(`/inspecciones/${inspection.id}`)}
                >
                  <div className="flex-1">
                    <p className="font-medium">{inspection.correlativo}</p>
                    <p className="text-sm text-muted-foreground">
                      {inspection.category?.name || "Categoría desconocida"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant="outline"
                      style={{
                        backgroundColor: PRIORITY_COLORS[inspection.priority as keyof typeof PRIORITY_COLORS],
                        color: "white",
                      }}
                    >
                      {inspection.priority}
                    </Badge>
                    <Badge
                      variant="outline"
                      style={{
                        backgroundColor: STATUS_COLORS[inspection.status as keyof typeof STATUS_COLORS],
                        color: "white",
                      }}
                    >
                      {STATUS_LABELS[inspection.status as keyof typeof STATUS_LABELS]}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-32 flex items-center justify-center text-muted-foreground">
              No hay inspecciones registradas
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
