import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useState } from "react";
import { toast } from "sonner";

export default function NuevaEvaluacion() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch reference data
  const { data: severidades } = trpc.referencias.severidades.useQuery();
  const { data: normativas } = trpc.normativa.list.useQuery({});
  const { data: proveedores } = trpc.proveedores.list.useQuery();

  // Mutation
  const createEvaluacion = trpc.evaluaciones.create.useMutation();

  // Form state
  const [formData, setFormData] = useState({
    numeroReporte: "",
    fecha: new Date().toISOString().split("T")[0],
    formaReporte: "",
    reportadoPor: "",
    entidadOrigen: "",
    descripcion: "",
    tipoOcurrencia: "",
    regulacion: "",
    normativaId: "",
    proveedorId: "",
    probabilidad: "3",
    severidadId: "3",
    impacto: "1",
  });

  if (loading || !user) {
    return <DashboardLayout>Cargando...</DashboardLayout>;
  }

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validate required fields
      if (!formData.numeroReporte || !formData.descripcion || !formData.tipoOcurrencia) {
        toast.error("Por favor complete los campos obligatorios");
        setIsSubmitting(false);
        return;
      }

      await createEvaluacion.mutateAsync({
        numeroReporte: formData.numeroReporte,
        fecha: new Date(formData.fecha),
        formaReporte: formData.formaReporte || undefined,
        reportadoPor: formData.reportadoPor || undefined,
        entidadOrigen: formData.entidadOrigen || undefined,
        descripcion: formData.descripcion,
        tipoOcurrencia: formData.tipoOcurrencia,
        regulacion: formData.regulacion || undefined,
        normativaId: formData.normativaId ? parseInt(formData.normativaId) : undefined,
        proveedorId: formData.proveedorId ? parseInt(formData.proveedorId) : undefined,
        probabilidad: parseInt(formData.probabilidad),
        severidadId: parseInt(formData.severidadId),
        impacto: parseInt(formData.impacto),
      });

      toast.success("Evaluación creada exitosamente");
      setLocation("/evaluaciones");
    } catch (error: any) {
      toast.error(error.message || "Error al crear la evaluación");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-4xl">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Nueva Evaluación de Riesgo</h1>
          <p className="text-gray-500 mt-1">Registrar un nuevo reporte de incidente o peligro operacional</p>
        </div>

        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle>Información del Reporte</CardTitle>
            <CardDescription>Completa todos los campos obligatorios (*)</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Row 1: Número de Reporte y Fecha */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="numeroReporte" className="font-semibold">
                    Número de Reporte *
                  </Label>
                  <Input
                    id="numeroReporte"
                    name="numeroReporte"
                    value={formData.numeroReporte}
                    onChange={handleChange}
                    placeholder="REP-2025-001"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="fecha" className="font-semibold">
                    Fecha *
                  </Label>
                  <Input
                    id="fecha"
                    name="fecha"
                    type="date"
                    value={formData.fecha}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              {/* Row 2: Forma de Reporte y Reportado Por */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="formaReporte" className="font-semibold">
                    Forma de Reporte
                  </Label>
                  <Input
                    id="formaReporte"
                    name="formaReporte"
                    value={formData.formaReporte}
                    onChange={handleChange}
                    placeholder="Email, Teléfono, etc."
                  />
                </div>
                <div>
                  <Label htmlFor="reportadoPor" className="font-semibold">
                    Reportado Por
                  </Label>
                  <Input
                    id="reportadoPor"
                    name="reportadoPor"
                    value={formData.reportadoPor}
                    onChange={handleChange}
                    placeholder="Nombre del reportante"
                  />
                </div>
              </div>

              {/* Row 3: Entidad de Origen y Proveedor */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="entidadOrigen" className="font-semibold">
                    Entidad de Origen
                  </Label>
                  <Input
                    id="entidadOrigen"
                    name="entidadOrigen"
                    value={formData.entidadOrigen}
                    onChange={handleChange}
                    placeholder="Organización o departamento"
                  />
                </div>
                <div>
                  <Label htmlFor="proveedorId" className="font-semibold">
                    Proveedor
                  </Label>
                  <Select value={formData.proveedorId} onValueChange={(value) => handleSelectChange("proveedorId", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar proveedor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Sin proveedor</SelectItem>
                      {proveedores?.map((p: any) => (
                        <SelectItem key={p.id} value={p.id.toString()}>
                          {p.nombre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Row 4: Tipo de Ocurrencia y Regulación */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="tipoOcurrencia" className="font-semibold">
                    Tipo de Ocurrencia *
                  </Label>
                  <Input
                    id="tipoOcurrencia"
                    name="tipoOcurrencia"
                    value={formData.tipoOcurrencia}
                    onChange={handleChange}
                    placeholder="Falla de equipo, Procedimiento incorrecto, etc."
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="regulacion" className="font-semibold">
                    Regulación Aplicable
                  </Label>
                  <Input
                    id="regulacion"
                    name="regulacion"
                    value={formData.regulacion}
                    onChange={handleChange}
                    placeholder="RAC 139.320, NSOAM B1, etc."
                  />
                </div>
              </div>

              {/* Row 5: Normativa */}
              <div>
                <Label htmlFor="normativaId" className="font-semibold">
                  Normativa
                </Label>
                <Select value={formData.normativaId} onValueChange={(value) => handleSelectChange("normativaId", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar normativa" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Sin normativa específica</SelectItem>
                    {normativas?.map((n: any) => (
                      <SelectItem key={n.id} value={n.id.toString()}>
                        {n.codigo} - {n.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Row 6: Descripción */}
              <div>
                <Label htmlFor="descripcion" className="font-semibold">
                  Descripción Detallada *
                </Label>
                <Textarea
                  id="descripcion"
                  name="descripcion"
                  value={formData.descripcion}
                  onChange={handleChange}
                  placeholder="Describa en detalle el incidente o peligro identificado..."
                  rows={5}
                  required
                />
              </div>

              {/* Row 7: Risk Assessment */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Evaluación de Riesgo</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="probabilidad" className="font-semibold">
                      Probabilidad *
                    </Label>
                    <Select value={formData.probabilidad} onValueChange={(value) => handleSelectChange("probabilidad", value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Remoto/Improbable</SelectItem>
                        <SelectItem value="2">2 - Ocasional</SelectItem>
                        <SelectItem value="3">3 - Probable</SelectItem>
                        <SelectItem value="4">4 - Frecuente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="severidadId" className="font-semibold">
                      Severidad *
                    </Label>
                    <Select value={formData.severidadId} onValueChange={(value) => handleSelectChange("severidadId", value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {severidades?.map((s: any) => (
                          <SelectItem key={s.id} value={s.id.toString()}>
                            {s.letra} - {s.nombre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="impacto" className="font-semibold">
                      Impacto *
                    </Label>
                    <Select value={formData.impacto} onValueChange={(value) => handleSelectChange("impacto", value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 - Bajo</SelectItem>
                        <SelectItem value="2">2 - Medio</SelectItem>
                        <SelectItem value="3">3 - Alto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex gap-4 justify-end pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation("/evaluaciones")}
                  disabled={isSubmitting}
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Guardando..." : "Guardar Evaluación"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
